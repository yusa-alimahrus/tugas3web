package main

import (
	"crud/backend/api"
	"crud/backend/pkg/env"
	"database/sql"
	"fmt"
	"log"
	"net/http"

	_ "github.com/go-sql-driver/mysql"
)

func init_db(db *sql.DB) {
	rows, err := db.Query("SELECT table_name FROM information_schema.tables WHERE table_name='mahasiswa'")
	if err != nil {
		log.Println(err)
	}

	found := false
	for rows.Next() {
		var temp string
		if err := rows.Scan(&temp); err != nil {
			log.Println(err)
			return
		}

		found = true
	}

	if !found {
		_, err := db.Query("CREATE TABLE mahasiswa (nim TINYTEXT, nama TINYTEXT, email TINYTEXT, jurusan TINYTEXT)")
		if err != nil {
			log.Println(err)
		}
	}
}


func main() {
	SQL_LOGIN, err := env.Get("SQL_LOGIN")
	if err != nil {
		log.Fatal(err);
	}
		
	var db *sql.DB
	db, err = sql.Open("mysql", SQL_LOGIN)
	if err != nil {
		log.Println(err)
	}

	// example: PORT=8080 in env var
	PORT, err := env.Get("PORT")
	if err != nil {
		log.Fatal(err)
	}

	if PORT == "" {
		PORT = ":8080"
	} else {
		PORT = ":" + PORT
	}

	init_db(db)

	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		api.Handler(w, r, db)
	})

	fmt.Printf("Server listening on %s\n", PORT)
	if err := http.ListenAndServe(PORT, nil); err != nil {
		log.Println(err)
	}
}