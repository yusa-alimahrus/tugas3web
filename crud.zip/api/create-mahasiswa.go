package api

import (
	"database/sql"
	"encoding/json"
	"net/http"
)

func CreateMahasiswa(w http.ResponseWriter, r *http.Request, db *sql.DB) {
	if r.Method != http.MethodPost {
		w.Header().Set("Allow", http.MethodPost)

		resp := ResponseNoData{Error: http.StatusText(http.StatusMethodNotAllowed)}
		byte_resp, _ := json.Marshal(resp)
		w.WriteHeader(http.StatusMethodNotAllowed)
		w.Header().Set("Content-Type", "application/json")
		w.Write(byte_resp)
		return
	}

	err := r.ParseForm()
	if err != nil || r.Header.Get("content-type") != "application/x-www-form-urlencoded" {
		resp := ResponseNoData{Error: "body must be using application/x-www-form-urlencoded"}
		byte_resp, _ := json.Marshal(resp)
		w.WriteHeader(http.StatusBadRequest)
		w.Header().Set("Content-Type", "application/json")
		w.Write(byte_resp)
		return
	}

	nim := r.FormValue("nim")
	nama := r.FormValue("nama")
	email := r.FormValue("email")
	jurusan := r.FormValue("jurusan")

	if (nim == "" || nama == "" || email == "" || jurusan == "") {
		resp := ResponseNoData{Error: "all fields are required: nim, nama, email, jurusan"}
		byte_resp, _ := json.Marshal(resp)
		w.WriteHeader(http.StatusBadRequest)
		w.Header().Set("Content-Type", "application/json")
		w.Write(byte_resp)
		return
	}

	_, err = db.Query("INSERT INTO mahasiswa(nim, nama, email, jurusan) VALUES(?, ?, ?, ?)", nim, nama, email, jurusan)
	if err != nil {
		resp := ResponseNoData{Error: http.StatusText(http.StatusMethodNotAllowed)}
		byte_resp, _ := json.Marshal(resp)
		w.WriteHeader(http.StatusInternalServerError)
		w.Write(byte_resp)
		return
	}

	resp := ResponseNoData{Success: true}
	byte_resp, _ := json.Marshal(resp)

	w.Header().Set("Content-Type", "application/json")
	w.Write(byte_resp)
} 