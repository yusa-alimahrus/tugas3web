package api

type MahasiswaData struct {
	Nim 	string `json:"nim"`
	Nama 	string `json:"nama"`
	Email 	string `json:"email"`
	Jurusan string `json:"jurusan"`
}

type Response struct {
	Success	bool 			`json:"success"`
	Error 	string 			`json:"error"`
	Data 	MahasiswaData	`json:"data"`
}

type ResponseNoData struct {
	Success bool 	`json:"success"`
	Error 	string 	`json:"error"`
}