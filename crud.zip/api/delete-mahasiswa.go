package api

import (
	"database/sql"
	"encoding/json"
	"net/http"
)

func DeleteMahasiswa(w http.ResponseWriter, r *http.Request, db *sql.DB) {
	if r.Method != http.MethodDelete {
		w.Header().Set("Allow", http.MethodDelete)

		resp := ResponseNoData{Error: http.StatusText(http.StatusMethodNotAllowed)}
		byte_resp, _ := json.Marshal(resp)
		w.WriteHeader(http.StatusMethodNotAllowed)
		w.Header().Set("Content-Type", "application/json")
		w.Write(byte_resp)
		return
	}

	NIMSearch := r.URL.Query().Get("nim")
	if NIMSearch == "" {
		resp := ResponseNoData{Error: "query 'nim' not specified"}
		byte_resp, _ := json.Marshal(resp)

		w.WriteHeader(http.StatusBadRequest)
		w.Header().Set("Content-Type", "application/json")
		w.Write(byte_resp)
		return
	}

	rows, err := db.Query("SELECT nim, nama, email, jurusan FROM mahasiswa WHERE nim=?", NIMSearch)
	if err != nil {
		resp := ResponseNoData{Error: http.StatusText(http.StatusMethodNotAllowed)}
		byte_resp, _ := json.Marshal(resp)
		w.WriteHeader(http.StatusInternalServerError)
		w.Write(byte_resp)
		return
	}

	next := rows.Next();
	if !next {
		resp := ResponseNoData{Error: "data with the specified nim not found"}
		byte_resp, _ := json.Marshal(resp)

		w.WriteHeader(http.StatusNotFound)
		w.Header().Set("Content-Type", "application/json")
		w.Write(byte_resp)
		return
	}

	_, err = db.Query("DELETE FROM mahasiswa WHERE nim = ?", NIMSearch)
	if err != nil {
		resp := ResponseNoData{Error: http.StatusText(http.StatusMethodNotAllowed)}
		byte_resp, _ := json.Marshal(resp)
		w.WriteHeader(http.StatusInternalServerError)
		w.Write(byte_resp)
		return
	}

	resp := ResponseNoData{Success: true}
	byte_resp, _ := json.Marshal(resp)

	w.Header().Set("Content-Type", "application/json")
	w.Write(byte_resp)
}