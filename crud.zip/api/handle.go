package api

import (
	"database/sql"
	"net/http"
	"strings"
)

func Handler(w http.ResponseWriter, r *http.Request, db *sql.DB) {
	path := strings.ToLower(r.URL.Path)

	switch path {
	case "/api/get-mahasiswa": 
		GetMahasiswa(w, r, db)
	case "/api/create-mahasiswa": 
		CreateMahasiswa(w, r, db)
	case "/api/update-mahasiswa": 
		UpdateMahasiswa(w, r, db)
	case "/api/delete-mahasiswa":
		DeleteMahasiswa(w, r, db)
	default:
		w.WriteHeader(http.StatusNotFound)
		w.Write([]byte(http.StatusText(http.StatusNotFound)))
	}
}