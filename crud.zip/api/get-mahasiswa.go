package api

import (
	"database/sql"
	"encoding/json"
	"net/http"
)

func GetMahasiswa(w http.ResponseWriter, r *http.Request, db *sql.DB) {
	if r.Method != http.MethodGet {
		w.Header().Set("Allow", http.MethodGet)

		resp := ResponseNoData{Error: http.StatusText(http.StatusMethodNotAllowed)}
		byte_resp, _ := json.Marshal(resp)
		w.WriteHeader(http.StatusMethodNotAllowed)
		w.Header().Set("Content-Type", "application/json")
		w.Write(byte_resp)
		return
	}

	NIMSearch := r.URL.Query().Get("nim")
	if NIMSearch == "" {
		resp := ResponseNoData{Error: "query 'nim' not specified"}
		byte_resp, _ := json.Marshal(resp)

		w.WriteHeader(http.StatusBadRequest)
		w.Header().Set("Content-Type", "application/json")
		w.Write(byte_resp)
		return
	}

	rows, err := db.Query("SELECT nim, nama, email, jurusan FROM mahasiswa WHERE nim=?", NIMSearch)
	if err != nil {
		resp := ResponseNoData{Error: http.StatusText(http.StatusMethodNotAllowed)}
		byte_resp, _ := json.Marshal(resp)
		w.WriteHeader(http.StatusInternalServerError)
		w.Write(byte_resp)
		return
	}

	next := rows.Next();
	if !next {
		resp := ResponseNoData{Error: "data with the specified nim not found"}
		byte_resp, _ := json.Marshal(resp)

		w.WriteHeader(http.StatusNotFound)
		w.Header().Set("Content-Type", "application/json")
		w.Write(byte_resp)
		return
	}

	var nim, nama, email, jurusan string
	rows.Scan(&nim, &nama, &email, &jurusan)

	resp := Response{
		Success: true,
		Data: MahasiswaData{nim, nama, email, jurusan},
	}
	byte_resp, _ := json.Marshal(resp)

	w.Header().Set("Content-Type", "application/json")
	w.Write(byte_resp)
}